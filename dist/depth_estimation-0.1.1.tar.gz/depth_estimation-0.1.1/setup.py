# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['depth_estimation']

package_data = \
{'': ['*']}

install_requires = \
['numpy>=1.20.1,<2.0.0',
 'opencv-python>=4.5.5,<5.0.0',
 'tensorflow>=2.7.0,<3.0.0']

entry_points = \
{'console_scripts': ['depth_estimation = depth_estimation:main']}

setup_kwargs = {
    'name': 'depth-estimation',
    'version': '0.1.1',
    'description': 'executable demonstration of TensorFlow implementation for depth estimation',
    'long_description': None,
    'author': 'Abdullah AlGhamdi',
    'author_email': None,
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
